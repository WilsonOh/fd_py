# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['fd_py']

package_data = \
{'': ['*']}

install_requires = \
['rich>=13.0.1,<14.0.0']

entry_points = \
{'console_scripts': ['fd_py = fd_py.main:main']}

setup_kwargs = {
    'name': 'fd-py',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Wilson Oh',
    'author_email': 'e0773510@u.nus.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
